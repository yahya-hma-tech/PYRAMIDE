export type Language = "fr" | "ar" | "en";

export interface Translations {
  nav: {
    home: string;
    services: string;
    emergency: string;
    coverage: string;
    about: string;
    faq: string;
    contact: string;
    getQuote: string;
    callNow: string;
  };
  emergencyBar: {
    badge: string;
    text: string;
    callAction: string;
  };
  hero: {
    badge: string;
    titleStart: string;
    titleHighlight: string;
    titleEnd: string;
    subtitle: string;
    ctaQuote: string;
    ctaCall: string;
    ctaWhatsapp: string;
    quickStats: {
      speed: string;
      speedSub: string;
      experience: string;
      experienceSub: string;
      coverage: string;
      coverageSub: string;
    };
  };
  services: {
    tag: string;
    title: string;
    subtitle: string;
    items: Array<{
      id: string;
      title: string;
      shortDesc: string;
      badge?: string;
    }>;
  };
  fesSpecial: {
    tag: string;
    title: string;
    desc: string;
    districts: string[];
    responseTime: string;
    phoneBanner: string;
  };
  demo: {
    title: string;
    status: string;
    floor: string;
    doorsOpen: string;
    doorsClosed: string;
    selectFloor: string;
  };
  quoteForm: {
    tag: string;
    title: string;
    subtitle: string;
    nameLabel: string;
    namePlaceholder: string;
    phoneLabel: string;
    phonePlaceholder: string;
    emailLabel: string;
    emailPlaceholder: string;
    serviceLabel: string;
    servicePlaceholder: string;
    servicesList: string[];
    cityLabel: string;
    cityPlaceholder: string;
    urgencyLabel: string;
    urgencyOptions: string[];
    messageLabel: string;
    messagePlaceholder: string;
    submitBtn: string;
    submitting: string;
    successTitle: string;
    successMessage: string;
    sentToEmailNotice: string;
    whatsappDirect: string;
    sendAnother: string;
    errorMessage: string;
  };
  faq: {
    tag: string;
    title: string;
    items: Array<{
      q: string;
      a: string;
    }>;
  };
  contact: {
    tag: string;
    title: string;
    subtitle: string;
    phoneLabel: string;
    emailLabel: string;
    addressLabel: string;
    hoursLabel: string;
  };
  footer: {
    tagline: string;
    rights: string;
    locationNote: string;
  };
}

export const translations: Record<Language, Translations> = {
  fr: {
    nav: {
      home: "Accueil",
      services: "Services",
      emergency: "Urgence 24/7",
      coverage: "Fès & Régions",
      about: "À propos",
      faq: "FAQ",
      contact: "Contact",
      getQuote: "Devis Gratuit",
      callNow: "06 00 00 00 00",
    },
    emergencyBar: {
      badge: "URGENCE 24/7",
      text: "Dépannage d'ascenseurs à Fès et région en moins de 30 min",
      callAction: "Appeler le 06 00 00 00 00",
    },
    hero: {
      badge: "Société d'ascenseurs agréée à Fès",
      titleStart: "Installation, Réparation &",
      titleHighlight: "Maintenance d'Ascenseurs",
      titleEnd: "à Fès",
      subtitle: "Intervention express 24h/24, contrats d'entretien certifiés et pièces d'origine pour copropriétés, hôtels, cliniques et villas.",
      ctaQuote: "Demander un devis",
      ctaCall: "Appeler d'urgence",
      ctaWhatsapp: "Message WhatsApp",
      quickStats: {
        speed: "< 30 min",
        speedSub: "Intervention à Fès",
        experience: "+14 ans",
        experienceSub: "Savoir-faire technique",
        coverage: "24h / 7j",
        coverageSub: "Disponibilité totale",
      },
    },
    services: {
      tag: "Nos Prestations",
      title: "Solutions Complètes pour Vos Ascenseurs",
      subtitle: "Une maintenance réactive et des installations conformes aux normes internationales à Fès et partout au Maroc.",
      items: [
        {
          id: "urgency",
          title: "Dépannage Urgent 24/7",
          shortDesc: "Déblocage de cabine et réparation immédiate de pannes électriques et mécaniques.",
          badge: "Express",
        },
        {
          id: "maintenance",
          title: "Contrats de Maintenance",
          shortDesc: "Visites périodiques préventives, graissage, réglages et carnet d'entretien numérique.",
        },
        {
          id: "installation",
          title: "Installation Neuve",
          shortDesc: "Étude et pose d'ascenseurs passagers, monte-charges et élévateurs PMR sur mesure.",
        },
        {
          id: "renovation",
          title: "Modernisation & Sécurité",
          shortDesc: "Mise aux normes actuelles, changement de cartes électroniques, cabines et moteurs.",
        },
      ],
    },
    fesSpecial: {
      tag: "Proximité Locale",
      title: "Présents Partout à Fès & Alentours",
      desc: "Nos techniciens basés à Fès interviennent rapidement dans tous les quartiers de la ville impériale et les villes voisines.",
      districts: ["Ville Nouvelle", "Narjiss & Saïss", "Route d'Immouzzer", "Zouagha & Bensouda", "Atlas & Champs de Course", "Meknès & Sefrou"],
      responseTime: "Délai moyen d'arrivée : 20 à 35 minutes",
      phoneBanner: "Une panne à Fès ? Appelez le 06 00 00 00 00",
    },
    demo: {
      title: "Simulation Cabine & Machinerie",
      status: "Système Opérationnel",
      floor: "Étage",
      doorsOpen: "Portes Ouvertes",
      doorsClosed: "Portes Fermées",
      selectFloor: "Sélectionner un niveau :",
    },
    quoteForm: {
      tag: "Contact & Devis Direct",
      title: "Demandez Votre Devis Gratuit",
      subtitle: "Remplissez ce formulaire court. Vos informations sont envoyées directement à notre équipe technique.",
      nameLabel: "Nom complet *",
      namePlaceholder: "Ex. : Mohammed Alami",
      phoneLabel: "Téléphone *",
      phonePlaceholder: "Ex. : 06 00 00 00 00",
      emailLabel: "Votre E-mail *",
      emailPlaceholder: "Ex. : votre.email@domaine.com",
      serviceLabel: "Type de service *",
      servicePlaceholder: "Sélectionnez un service",
      servicesList: [
        "Dépannage d'urgence 24/7",
        "Contrat de maintenance préventive",
        "Installation d'ascenseur neuf",
        "Modernisation / Rénovation",
        "Diagnostic & Contrôle de sécurité",
      ],
      cityLabel: "Ville / Quartier à Fès",
      cityPlaceholder: "Ex. : Route d'Immouzzer, Fès",
      urgencyLabel: "Degré d'urgence",
      urgencyOptions: [
        "Urgence immédiate (Cabine bloquée / Panne)",
        "Dans les 24h à 48h",
        "Projet / Devis comparatif",
      ],
      messageLabel: "Détails de la demande",
      messagePlaceholder: "Type de bâtiment, nombre d'étages, marque de l'appareil si connue...",
      submitBtn: "Envoyer ma demande",
      submitting: "Envoi en cours...",
      successTitle: "Demande envoyée avec succès !",
      successMessage: "Merci. Vos informations ont été transmises directement à notre responsable technique.",
      sentToEmailNotice: "Un e-mail de confirmation a été envoyé à YAHYA.HMAMI.CONTACT@gmail.com",
      whatsappDirect: "Pour une urgence immédiate, écrivez-nous sur WhatsApp",
      sendAnother: "Envoyer une autre demande",
      errorMessage: "Une erreur est survenue lors de l'envoi. Veuillez nous contacter directement au 06 00 00 00 00 ou par WhatsApp.",
    },
    faq: {
      tag: "Questions Fréquentes",
      title: "Tout Ce Que Vous Devez Savoir",
      items: [
        {
          q: "En combien de temps intervenez-vous en urgence à Fès ?",
          a: "Notre équipe d'astreinte intervient en moins de 30 minutes sur tous les quartiers de Fès, avec priorité absolue si des personnes sont bloquées en cabine.",
        },
        {
          q: "Prenez-vous en charge toutes les marques d'ascenseurs ?",
          a: "Oui, nos techniciens sont formés sur toutes les marques (Otis, Schindler, Kone, Thyssenkrupp, Sodimas et modèles hydrauliques ou électromécaniques).",
        },
        {
          q: "Le devis est-il gratuit et sans engagement ?",
          a: "100% gratuit. Nous étudions votre besoin et effectuons un diagnostic sur place à Fès avant tout engagement.",
        },
        {
          q: "Proposez-vous des contrats de maintenance annuels ?",
          a: "Oui, avec visites préventives mensuelles, graissage, carnet de bord et dépannage prioritaire 24h/24 pour syndics et professionnels.",
        },
      ],
    },
    contact: {
      tag: "Coordonnées",
      title: "Contactez Pyramide Ascenseur",
      subtitle: "Nous sommes à votre écoute pour toute demande d'intervention, audit ou devis.",
      phoneLabel: "Téléphone & Urgences 24/7",
      emailLabel: "E-mail Officiel",
      addressLabel: "Adresse à Fès",
      hoursLabel: "Disponibilité",
    },
    footer: {
      tagline: "Société de référence pour l'installation, le dépannage et l'entretien d'ascenseurs à Fès et partout au Maroc.",
      rights: "Tous droits réservés.",
      locationNote: "Basé à Fès, Royaume du Maroc",
    },
  },

  ar: {
    nav: {
      home: "الرئيسية",
      services: "خدماتنا",
      emergency: "طوارئ 24/7",
      coverage: "فاس ونواحيها",
      about: "من نحن",
      faq: "أسئلة شائعة",
      contact: "اتصل بنا",
      getQuote: "طلب تسعيرة",
      callNow: "06 00 00 00 00",
    },
    emergencyBar: {
      badge: "طوارئ 24/7",
      text: "إصلاح فوري للمصاعد في فاس والنواحي في أقل من 30 دقيقة",
      callAction: "اتصل الآن: 06 00 00 00 00",
    },
    hero: {
      badge: "شركة مصاعد معتمدة بمدينة فاس",
      titleStart: "تركيب، إصلاح و",
      titleHighlight: "صيانة المصاعد الكهربائية",
      titleEnd: "بمدينة فاس",
      subtitle: "تدخل سريع على مدار 24 ساعة، عقود صيانة معتمدة وقطع غيار أصلية للإقامات السكنية، الفنادق، المصحات والمنازل.",
      ctaQuote: "طلب تسعيرة مجانية",
      ctaCall: "اتصال عاجل للطوارئ",
      ctaWhatsapp: "تواصل عبر واتساب",
      quickStats: {
        speed: "أقل من 30 دقيقة",
        speedSub: "سرعة التدخل بفاس",
        experience: "+14 سنة",
        experienceSub: "خبرة تقنية معتمدة",
        coverage: "24/7",
        coverageSub: "جاهزية دائمة",
      },
    },
    services: {
      tag: "خدماتنا المتميزة",
      title: "حلول شاملة واحترافية لمصاعدكم",
      subtitle: "صيانة استباقية وتركيبات مطابقة لأعلى المعايير العالمية في فاس وكافة المدن المغربية.",
      items: [
        {
          id: "urgency",
          title: "إصلاح فوري وطوارئ 24/7",
          shortDesc: "إنقاذ العالقين وإصلاح الأعطال الميكانيكية والكهربائية بأقصى سرعة.",
          badge: "طوارئ سريعة",
        },
        {
          id: "maintenance",
          title: "عقود صيانة دورية",
          shortDesc: "فحوصات وقائية شهرية، تزييت وضبط الأجهزة، وسجل صيانة رقمي معتمد.",
        },
        {
          id: "installation",
          title: "تركيب مصاعد جديدة",
          shortDesc: "دراسة وتركيب مصاعد الركاب، مصاعد الحمولات ومصاعد ذوي الاحتياجات الخاصة.",
        },
        {
          id: "renovation",
          title: "تحديث وتأمين المصاعد",
          shortDesc: "تطوير اللوحات الإلكترونية، تجديد المقصورات، والمطابقة لمعايير السلامة.",
        },
      ],
    },
    fesSpecial: {
      tag: "القرب والسرعة",
      title: "متواجدون في جميع أحياء فاس والنواحي",
      desc: "فريقنا التقني متمركز بمدينة فاس لضمان وصول سريع إلى كافة الأحياء والمدن المجاورة.",
      districts: ["المدينة الجديدة", "النرجس وسايس", "طريق إيموزار", "زوين وسيدي براهيم", "الأطلس وشام دو كورس", "مكناس وصفرو"],
      responseTime: "متوسط وقت الوصول: بين 20 و 35 دقيقة",
      phoneBanner: "عطب في المصعد بفاس؟ اتصل فوراً على 06 00 00 00 00",
    },
    demo: {
      title: "محاكاة حركة المصعد",
      status: "النظام يعمل بكفاءة",
      floor: "الطابق",
      doorsOpen: "الأبواب مفتوحة",
      doorsClosed: "الأبواب مغلقة",
      selectFloor: "اختر الطابق :",
    },
    quoteForm: {
      tag: "طلب مباشر وسريع",
      title: "اطلب تسعيرة مجانية الآن",
      subtitle: "املأ هذا النموذج البسيط، وسيتم إرسال كافة التفاصيل مباشرة إلى فريقنا الهندسي.",
      nameLabel: "الاسم الكامل *",
      namePlaceholder: "مثال: محمد العلمي",
      phoneLabel: "رقم الهاتف *",
      phonePlaceholder: "مثال: 06 00 00 00 00",
      emailLabel: "البريد الإلكتروني *",
      emailPlaceholder: "مثال: your.email@domain.com",
      serviceLabel: "نوع الخدمة المطلوبة *",
      servicePlaceholder: "اختر الخدمة",
      servicesList: [
        "إصلاح عاجل وطوارئ 24/7",
        "عقد صيانة دورية وقائية",
        "تركيب مصعد جديد",
        "تحديث وتجديد مصعد قديم",
        "فحص شامل ومراقبة السلامة",
      ],
      cityLabel: "المدينة / الحي بمدينة فاس",
      cityPlaceholder: "مثال: طريق إيموزار، فاس",
      urgencyLabel: "درجة الاستعجال",
      urgencyOptions: [
        "طوارئ عاجلة جداً (أشخاص عالقون / توقف تام)",
        "خلال 24 إلى 48 ساعة",
        "مشروع مستقبلي / مقارنة أسعار",
      ],
      messageLabel: "تفاصيل الطلب",
      messagePlaceholder: "نوع البناية، عدد الطوابق، ماركة المصعد إن عُرفت...",
      submitBtn: "إرسال الطلب الآن",
      submitting: "جارٍ الإرسال...",
      successTitle: "تم إرسال طلبك بنجاح !",
      successMessage: "شكراً لثقتكم. تم توجيه كافة بياناتكم مباشرة إلى المسؤول التقني.",
      sentToEmailNotice: "تم توجيه نسخة من الطلب إلى البريد: YAHYA.HMAMI.CONTACT@gmail.com",
      whatsappDirect: "للحالات العاجلة، راسلنا مباشرة عبر واتساب",
      sendAnother: "إرسال طلب آخر",
      errorMessage: "حدث خطأ أثناء الإرسال. يرجى الاتصال بنا مباشرة على 06 00 00 00 00 أو عبر واتساب.",
    },
    faq: {
      tag: "الأسئلة الشائعة",
      title: "كل ما تحتاج معرفته عن خدماتنا",
      items: [
        {
          q: "كم من الوقت يستغرق وصولكم في حالة الطوارئ بفاس؟",
          a: "فريق المداومة يصل في أقل من 30 دقيقة إلى مختلف أحياء مدينة فاس، مع إعطاء الأولوية القصوى لحالات الأشخاص العالقين.",
        },
        {
          q: "هل تقومون بصيانة مختلف أنواع وماركات المصاعد؟",
          a: "نعم، مهندسونا وتقنيونا مدربون على كافة الماركات العالمية (Otis، Schindler، Kone، Thyssenkrupp، والمصاعد الهيدروليكية وغيرها).",
        },
        {
          q: "هل المعاينة والتسعيرة مجانية وبدون التزام؟",
          a: "نعم، 100% مجانية. نقوم بزيارة المكان وتشخيص الحالة وتوفير مقايسة شفافة ومفصلة دون أي إلزام.",
        },
        {
          q: "هل تمنحون عقود صيانة سنوية للإقامات والسانديك؟",
          a: "نعم، نقدم عقوداً شاملة مع زيارات منتظمة شهرياً، صيانة وقائية، وطوارئ مجانية 24/24 لملاك الإقامات والشركات.",
        },
      ],
    },
    contact: {
      tag: "معلومات التواصل",
      title: "تواصل مع بيراميد للمصاعد بفاس",
      subtitle: "نحن رهن إشارتكم لجميع استفساراتكم وحالات الطوارئ والمشاريع.",
      phoneLabel: "الهاتف والطوارئ 24/7",
      emailLabel: "البريد الإلكتروني الرسمي",
      addressLabel: "العنوان بمدينة فاس",
      hoursLabel: "أوقات العمل والجاهزية",
    },
    footer: {
      tagline: "الشركة الرائدة في تركيب وصيانة وإصلاح المصاعد بمدينة فاس وكافة ربوع المملكة المغربية.",
      rights: "جميع الحقوق محفوظة.",
      locationNote: "فاس، المملكة المغربية",
    },
  },

  en: {
    nav: {
      home: "Home",
      services: "Services",
      emergency: "24/7 Emergency",
      coverage: "Fez & Regions",
      about: "About Us",
      faq: "FAQ",
      contact: "Contact",
      getQuote: "Free Quote",
      callNow: "06 00 00 00 00",
    },
    emergencyBar: {
      badge: "24/7 EMERGENCY",
      text: "Elevator repair in Fez and surrounding areas in under 30 minutes",
      callAction: "Call 06 00 00 00 00",
    },
    hero: {
      badge: "Certified Elevator Company in Fez, Morocco",
      titleStart: "Installation, Repair &",
      titleHighlight: "Elevator Maintenance",
      titleEnd: "in Fez",
      subtitle: "24/7 rapid emergency response, certified maintenance agreements, and genuine parts for residential buildings, hotels, clinics, and private villas.",
      ctaQuote: "Get a Free Quote",
      ctaCall: "Emergency Call",
      ctaWhatsapp: "WhatsApp Chat",
      quickStats: {
        speed: "< 30 min",
        speedSub: "Response time in Fez",
        experience: "+14 Years",
        experienceSub: "Proven Expertise",
        coverage: "24h / 7d",
        coverageSub: "Always Available",
      },
    },
    services: {
      tag: "Our Services",
      title: "Complete Elevator Solutions",
      subtitle: "Reliable maintenance and modern installations compliant with international safety standards across Fez and Morocco.",
      items: [
        {
          id: "urgency",
          title: "24/7 Emergency Repair",
          shortDesc: "Instant passenger rescue and fast troubleshooting for electrical and mechanical failures.",
          badge: "Express",
        },
        {
          id: "maintenance",
          title: "Maintenance Contracts",
          shortDesc: "Scheduled preventive visits, lubrication, calibration, and digital logbook records.",
        },
        {
          id: "installation",
          title: "New Installation",
          shortDesc: "Custom design and installation of passenger lifts, freight elevators, and accessibility solutions.",
        },
        {
          id: "renovation",
          title: "Modernization & Safety",
          shortDesc: "Control board upgrades, cabin refurbishment, and compliance with the latest safety codes.",
        },
      ],
    },
    fesSpecial: {
      tag: "Local Presence",
      title: "Active Across Fez & Neighboring Cities",
      desc: "Our technical team based in Fez delivers rapid intervention across all metropolitan districts and neighboring regions.",
      districts: ["Ville Nouvelle", "Narjiss & Saïss", "Route d'Immouzzer", "Zouagha & Bensouda", "Atlas & Champs de Course", "Meknes & Sefrou"],
      responseTime: "Average arrival time: 20 to 35 minutes",
      phoneBanner: "Elevator issue in Fez? Call 06 00 00 00 00 immediately",
    },
    demo: {
      title: "Elevator Cabin Simulation",
      status: "System Active & Healthy",
      floor: "Floor",
      doorsOpen: "Doors Open",
      doorsClosed: "Doors Closed",
      selectFloor: "Select a level:",
    },
    quoteForm: {
      tag: "Quick Inquiry",
      title: "Request Your Free Quote",
      subtitle: "Fill out this simple form. Your information is delivered directly to our senior technician.",
      nameLabel: "Full Name *",
      namePlaceholder: "e.g., John Doe",
      phoneLabel: "Phone Number *",
      phonePlaceholder: "e.g., 06 00 00 00 00",
      emailLabel: "Email Address *",
      emailPlaceholder: "e.g., you@domain.com",
      serviceLabel: "Service Type *",
      servicePlaceholder: "Select a service",
      servicesList: [
        "24/7 Emergency Repair",
        "Preventive Maintenance Contract",
        "New Elevator Installation",
        "Modernization / Refurbishment",
        "Safety Audit & Inspection",
      ],
      cityLabel: "City / District in Fez",
      cityPlaceholder: "e.g., Route d'Immouzzer, Fez",
      urgencyLabel: "Urgency Level",
      urgencyOptions: [
        "Immediate Emergency (Trapped passengers / Total breakdown)",
        "Within 24 to 48 hours",
        "Upcoming project / Quote comparison",
      ],
      messageLabel: "Project Details",
      messagePlaceholder: "Building type, number of stops, brand if known...",
      submitBtn: "Send Request",
      submitting: "Sending...",
      successTitle: "Request Sent Successfully!",
      successMessage: "Thank you. Your details were delivered directly to our technical lead.",
      sentToEmailNotice: "A notification was dispatched to YAHYA.HMAMI.CONTACT@gmail.com",
      whatsappDirect: "For immediate emergency support, reach us on WhatsApp",
      sendAnother: "Send Another Message",
      errorMessage: "Failed to send form automatically. Please call us directly at 06 00 00 00 00 or chat on WhatsApp.",
    },
    faq: {
      tag: "FAQ",
      title: "Frequently Asked Questions",
      items: [
        {
          q: "How fast do you respond to emergencies in Fez?",
          a: "Our standby team arrives on-site in under 30 minutes in Fez, with immediate priority given to trapped passenger situations.",
        },
        {
          q: "Do you service all elevator brands?",
          a: "Yes, our certified technicians work on all major brands (Otis, Schindler, Kone, Thyssenkrupp, Sodimas, hydraulic and traction lifts).",
        },
        {
          q: "Is the technical quote free with no obligation?",
          a: "100% free. We inspect the site in Fez, diagnose the requirements, and provide a clear transparent quote.",
        },
        {
          q: "Do you provide annual contracts for building managers?",
          a: "Yes, including monthly checks, preventive maintenance, digital maintenance reports, and priority 24/7 dispatching.",
        },
      ],
    },
    contact: {
      tag: "Get in Touch",
      title: "Contact Pyramide Ascenseur",
      subtitle: "We are available 24/7 to assist with emergencies, maintenance, and installations in Fez.",
      phoneLabel: "Phone & 24/7 Emergency",
      emailLabel: "Official Email",
      addressLabel: "Address in Fez",
      hoursLabel: "Working Hours",
    },
    footer: {
      tagline: "Leading elevator engineering firm for installation, maintenance, and emergency repairs in Fez and Morocco.",
      rights: "All rights reserved.",
      locationNote: "Fez, Kingdom of Morocco",
    },
  },
};
