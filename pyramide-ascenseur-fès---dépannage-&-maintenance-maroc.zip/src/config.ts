export const SITE_CONFIG = {
  name: "Pyramide Ascenseur",
  nameAr: "بيراميد للمصاعد - فاس",
  tagline: "Spécialiste des ascenseurs à Fès et au Maroc",
  phoneDisplay: "06 00 00 00 00",
  phoneHref: "+212600000000",
  whatsappNumber: "212600000000",
  email: "YAHYA.HMAMI.CONTACT@gmail.com",
  city: "Fès",
  country: "Maroc",
  address: "Avenue des F.A.R, Ville Nouvelle, Fès, Maroc",
  addressAr: "شارع القوات المسلحة الملكية، المدينة الجديدة، فاس، المغرب",
  hours: "Lun - Sam : 08:00 - 19:00",
  emergencyHours: "Urgences 24h/24 & 7j/7",
  serviceArea: "Fès, Meknès et tout le Maroc",
  serviceAreaAr: "فاس، مكناس وكافة المدن المغربية",
  formActionUrl: "https://formsubmit.co/ajax/YAHYA.HMAMI.CONTACT@gmail.com",
  yearFounded: 2011,
} as const;

export const phoneLink = `tel:${SITE_CONFIG.phoneHref}`;
export const emailLink = `mailto:${SITE_CONFIG.email}`;
export const getWhatsappLink = (message?: string) => {
  const defaultMsg = "Bonjour Pyramide Ascenseur Fès, j'ai besoin d'une intervention pour mon ascenseur.";
  return `https://wa.me/${SITE_CONFIG.whatsappNumber}?text=${encodeURIComponent(message || defaultMsg)}`;
};
