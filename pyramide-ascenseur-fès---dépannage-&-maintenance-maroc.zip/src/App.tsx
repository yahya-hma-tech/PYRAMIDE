import { useState, useEffect } from "react";
import { EmergencyBanner } from "./components/EmergencyBanner";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { ServicesSection } from "./components/ServicesSection";
import { FesCoverageSection } from "./components/FesCoverageSection";
import { QuoteContactForm } from "./components/QuoteContactForm";
import { FAQSection } from "./components/FAQSection";
import { ContactDirectSection } from "./components/ContactDirectSection";
import { Footer } from "./components/Footer";
import { FloatingActions } from "./components/FloatingActions";
import { translations, type Language } from "./translations";

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("site_lang") as Language | null;
      if (saved && (saved === "ar" || saved === "fr" || saved === "en")) {
        return saved;
      }
    }
    return "fr";
  });

  const t = translations[lang];

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
      try {
        localStorage.setItem("site_lang", lang);
      } catch {
        // Ignore private browsing storage restrictions
      }

      // Sync document title dynamically
      if (lang === "ar") {
        document.title = "بيراميد للمصاعد فاس - صيانة وإصلاح وتركيب المصاعد بالمغرب";
      } else if (lang === "en") {
        document.title = "Pyramide Elevators Fez - Repair, Installation & Maintenance Morocco";
      } else {
        document.title = "Pyramide Ascenseur Fès - Dépannage, Maintenance & Installation Maroc";
      }
    }
  }, [lang]);

  return (
    <div className={`min-h-screen flex flex-col font-sans ${lang === "ar" ? "rtl" : "ltr"}`}>
      {/* Top Emergency Indicator Bar */}
      <EmergencyBanner t={t.emergencyBar} />

      {/* Main Header / Navigation */}
      <Navbar currentLang={lang} onLanguageChange={setLang} t={t.nav} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Hero Section with Interactive Elevator Demonstration */}
        <Hero t={t.hero} demoT={t.demo} />

        {/* 4 Core Services */}
        <ServicesSection t={t.services} />

        {/* Local Coverage in Fès & Regions */}
        <FesCoverageSection t={t.fesSpecial} />

        {/* Form Directly Posting to YAHYA.HMAMI.CONTACT@gmail.com */}
        <QuoteContactForm t={t.quoteForm} />

        {/* FAQ Section */}
        <FAQSection t={t.faq} />

        {/* Direct Contact Cards */}
        <ContactDirectSection t={t.contact} />
      </main>

      {/* Footer */}
      <Footer currentLang={lang} t={t.footer} />

      {/* Quick Access Floating Buttons (Call & WhatsApp) */}
      <FloatingActions />
    </div>
  );
}
