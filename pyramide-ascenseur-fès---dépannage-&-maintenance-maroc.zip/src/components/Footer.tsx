import React from "react";
import { PhoneCall, Mail, MapPin, Clock } from "lucide-react";
import { SITE_CONFIG, phoneLink, emailLink } from "../config";
import type { Language, Translations } from "../translations";

interface FooterProps {
  currentLang: Language;
  t: Translations["footer"];
}

export const Footer: React.FC<FooterProps> = ({ currentLang, t }) => {
  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800/80 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 pb-10 border-b border-slate-800/70">
          {/* Brand & Mission (4 cols) */}
          <div className="lg:col-span-5 space-y-3 text-center md:text-left rtl:md:text-right">
            <div className="flex items-center justify-center md:justify-start rtl:md:justify-start gap-2.5">
              <span className="text-white font-extrabold text-lg tracking-tight">
                PYRAMIDE ASCENSEUR
              </span>
              <span className="px-2 py-0.5 rounded-md bg-blue-900/60 text-blue-300 font-bold text-[10px] tracking-wider uppercase border border-blue-800/80">
                {currentLang === "ar" ? "فاس · المغرب" : "Fès · Maroc"}
              </span>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-md mx-auto md:mx-0">
              {t.tagline}
            </p>

            <div className="pt-2 flex flex-wrap items-center justify-center md:justify-start rtl:md:justify-start gap-3">
              <a
                href={phoneLink}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-500/20 text-orange-400 border border-orange-500/30 font-bold text-xs hover:bg-orange-500/30 transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>{SITE_CONFIG.phoneDisplay}</span>
              </a>
              <span className="text-slate-500 text-[11px] font-medium">
                {currentLang === "ar" ? "خدمة مستمرة 24/7" : "Service 24/7"}
              </span>
            </div>
          </div>

          {/* Quick Navigation (3 cols) */}
          <div className="lg:col-span-3 text-center md:text-left rtl:md:text-right">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-3">
              {currentLang === "ar" ? "روابط سريعة" : "Navigation"}
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <a href="#accueil" className="hover:text-white transition-colors py-1">
                {currentLang === "ar" ? "الرئيسية" : "Accueil"}
              </a>
              <a href="#services" className="hover:text-white transition-colors py-1">
                {currentLang === "ar" ? "الخدمات" : "Services"}
              </a>
              <a href="#fes" className="hover:text-white transition-colors py-1">
                {currentLang === "ar" ? "فاس والنواحي" : "Fès & Région"}
              </a>
              <a href="#devis" className="hover:text-white transition-colors py-1">
                {currentLang === "ar" ? "طلب تسعيرة" : "Devis Gratuit"}
              </a>
              <a href="#faq" className="hover:text-white transition-colors py-1">
                {currentLang === "ar" ? "الأسئلة الشائعة" : "FAQ"}
              </a>
              <a href="#contact" className="hover:text-white transition-colors py-1">
                {currentLang === "ar" ? "اتصل بنا" : "Contact"}
              </a>
            </div>
          </div>

          {/* Dedicated Clean Personal & Contact Details (4 cols) */}
          <div className="lg:col-span-4 bg-slate-900/60 rounded-2xl p-4 sm:p-5 border border-slate-800">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-3 text-center md:text-left rtl:md:text-right">
              {currentLang === "ar" ? "معلومات التواصل المباشر" : "Coordonnées Officielles"}
            </h4>

            <div className="space-y-2.5 text-xs">
              {/* Phone */}
              <div className="flex items-start gap-2.5">
                <PhoneCall className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-[10px] text-slate-500 uppercase font-semibold">
                    {currentLang === "ar" ? "الهاتف" : "Téléphone"}
                  </span>
                  <a
                    href={phoneLink}
                    className="font-bold text-white hover:text-orange-400 transition-colors"
                  >
                    {SITE_CONFIG.phoneDisplay}
                  </a>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <span className="block text-[10px] text-slate-500 uppercase font-semibold">
                    {currentLang === "ar" ? "البريد الإلكتروني" : "E-mail direct"}
                  </span>
                  <a
                    href={emailLink}
                    className="font-medium text-slate-200 hover:text-white transition-colors break-all block"
                  >
                    {SITE_CONFIG.email}
                  </a>
                </div>
              </div>

              {/* Address */}
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-[10px] text-slate-500 uppercase font-semibold">
                    {currentLang === "ar" ? "المقر بمدينة فاس" : "Adresse"}
                  </span>
                  <span className="text-slate-300 leading-snug">
                    {currentLang === "ar" ? SITE_CONFIG.addressAr : SITE_CONFIG.address}
                  </span>
                </div>
              </div>

              {/* Hours */}
              <div className="flex items-center gap-2.5 pt-1 text-[11px] text-slate-400 border-t border-slate-800/80">
                <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <span>{SITE_CONFIG.hours}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Cleanly Stacked on Mobile, Neat on Desktop */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left rtl:sm:text-right text-[11px] text-slate-500">
          <p>
            © {new Date().getFullYear()} {SITE_CONFIG.name} · {t.rights}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 text-slate-400">
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
              {t.locationNote}
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
