import React from "react";
import { MapPin, PhoneCall, Clock, CheckCircle } from "lucide-react";
import { SITE_CONFIG, phoneLink } from "../config";
import type { Translations } from "../translations";

interface FesCoverageSectionProps {
  t: Translations["fesSpecial"];
}

export const FesCoverageSection: React.FC<FesCoverageSectionProps> = ({ t }) => {
  return (
    <section id="fes" className="py-16 bg-slate-900 text-white relative overflow-hidden">
      {/* Decorative SVG grid lines */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7 space-y-5">
            <span className="text-xs font-bold uppercase tracking-wider text-orange-400 bg-orange-950/80 border border-orange-800/80 px-3 py-1 rounded-full">
              {t.tag}
            </span>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight">
              {t.title}
            </h2>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl">
              {t.desc}
            </p>

            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 bg-emerald-950/50 border border-emerald-800/60 p-3 rounded-xl max-w-md">
              <Clock className="w-4 h-4 shrink-0" />
              <span>{t.responseTime}</span>
            </div>

            {/* Fès Districts Pills */}
            <div className="pt-2">
              <p className="text-xs uppercase font-bold tracking-wider text-slate-400 mb-3">
                Quartiers & Zones Couvertes à Fès :
              </p>
              <div className="flex flex-wrap gap-2">
                {t.districts.map((district) => (
                  <div
                    key={district}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/90 border border-slate-700/80 text-xs font-medium text-slate-200"
                  >
                    <MapPin className="w-3.5 h-3.5 text-blue-400" />
                    <span>{district}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Call Action Card */}
          <div className="lg:col-span-5">
            <div className="bg-gradient-to-br from-slate-800 to-blue-950 border border-slate-700 rounded-2xl p-6 sm:p-8 shadow-2xl">
              {/* Top Status Row (in normal flow, never overlaps title) */}
              <div className="flex items-center justify-between gap-2 mb-4">
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-orange-400 bg-orange-950/80 border border-orange-800/80 px-2.5 py-1 rounded-full">
                  <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
                  Disponible maintenant
                </span>
                <span className="text-[11px] text-slate-400 font-medium">24h/24 & 7j/7</span>
              </div>

              <h3 className="text-lg sm:text-xl font-bold text-white mb-2 leading-snug">
                {t.phoneBanner}
              </h3>
              <p className="text-xs text-slate-300 mb-6 leading-relaxed">
                Intervention immédiate jour & nuit pour blocage ou panne critique à Fès.
              </p>

              <a
                href={phoneLink}
                className="w-full flex items-center justify-center gap-3 py-4 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-black text-lg shadow-lg shadow-orange-500/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <PhoneCall className="w-5 h-5 animate-bounce" />
                <span>{SITE_CONFIG.phoneDisplay}</span>
              </a>

              <div className="mt-5 pt-4 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  Techniciens certifiés
                </span>
                <span className="flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  Toutes marques
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
