import React from "react";
import { Siren, Wrench, Building2, ShieldCheck, ArrowRight } from "lucide-react";
import type { Translations } from "../translations";

interface ServicesSectionProps {
  t: Translations["services"];
}

const SERVICE_ICONS: Record<string, React.ReactNode> = {
  urgency: <Siren className="w-6 h-6 text-orange-500" />,
  maintenance: <Wrench className="w-6 h-6 text-blue-600" />,
  installation: <Building2 className="w-6 h-6 text-indigo-600" />,
  renovation: <ShieldCheck className="w-6 h-6 text-emerald-600" />,
};

export const ServicesSection: React.FC<ServicesSectionProps> = ({ t }) => {
  return (
    <section id="services" className="py-16 sm:py-20 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-100">
            {t.tag}
          </span>
          <h2 className="mt-3 text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.title}
          </h2>
          <p className="mt-3 text-slate-600 text-sm sm:text-base leading-relaxed">
            {t.subtitle}
          </p>
        </div>

        {/* 4 Clean, Compact Service Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {t.items.map((item) => {
            const isUrgent = item.id === "urgency";
            return (
              <div
                key={item.id}
                className={`relative rounded-2xl p-6 transition-all duration-200 hover:-translate-y-1 ${
                  isUrgent
                    ? "bg-gradient-to-b from-orange-50/70 to-white border-2 border-orange-200 shadow-sm"
                    : "bg-slate-50/60 hover:bg-white border border-slate-200/80 hover:border-blue-200 hover:shadow-md"
                }`}
              >
                {item.badge && (
                  <span className="absolute top-4 right-4 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-orange-500 text-white shadow-xs">
                    {item.badge}
                  </span>
                )}

                <div className="w-12 h-12 rounded-xl bg-white shadow-2xs border border-slate-100 flex items-center justify-center mb-4">
                  {SERVICE_ICONS[item.id] || <Wrench className="w-6 h-6 text-blue-600" />}
                </div>

                <h3 className="text-lg font-bold text-slate-900 mb-2">
                  {item.title}
                </h3>

                <p className="text-sm text-slate-600 leading-relaxed mb-5">
                  {item.shortDesc}
                </p>

                <a
                  href="#devis"
                  className={`inline-flex items-center gap-1.5 text-xs font-bold transition-colors ${
                    isUrgent ? "text-orange-600 hover:text-orange-700" : "text-blue-600 hover:text-blue-800"
                  }`}
                >
                  <span>Demander une intervention</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
