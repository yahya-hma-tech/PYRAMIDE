import React, { useState } from "react";
import { PhoneCall, Menu, X, ArrowUpRight } from "lucide-react";
import { SITE_CONFIG, phoneLink } from "../config";
import { LanguageSelector } from "./LanguageSelector";
import type { Language, Translations } from "../translations";

interface NavbarProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  t: Translations["nav"];
}

export const Navbar: React.FC<NavbarProps> = ({ currentLang, onLanguageChange, t }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & City Badge */}
          <a href="#accueil" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-900 to-blue-700 flex items-center justify-center text-white shadow-md shadow-blue-900/20 group-hover:scale-105 transition-transform">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-none stroke-current" strokeWidth="2">
                <polygon points="12,3 2,20 22,20" className="fill-blue-600/30" />
                <rect x="9.5" y="11" width="5" height="9" rx="1" className="fill-white stroke-none" />
                <line x1="12" y1="12" x2="12" y2="19" stroke="#0B1F3A" strokeWidth="1.2" />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold tracking-tight text-slate-900 text-lg leading-tight">
                  PYRAMIDE
                </span>
                <span className="text-xs font-bold text-blue-600 tracking-wider">
                  ASCENSEUR
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-500 leading-none">
                {currentLang === "ar" ? "فاس · المغرب" : "Fès · Maroc"}
              </p>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-semibold text-slate-600">
            <a href="#services" className="hover:text-blue-600 transition-colors">
              {t.services}
            </a>
            <a href="#fes" className="hover:text-blue-600 transition-colors">
              {t.coverage}
            </a>
            <a href="#simulation" className="hover:text-blue-600 transition-colors">
              {t.home}
            </a>
            <a href="#faq" className="hover:text-blue-600 transition-colors">
              {t.faq}
            </a>
            <a href="#contact" className="hover:text-blue-600 transition-colors">
              {t.contact}
            </a>
          </nav>

          {/* Right Actions: Lang Switcher + Emergency Phone + Quote */}
          <div className="hidden sm:flex items-center gap-3">
            <LanguageSelector currentLang={currentLang} onLanguageChange={onLanguageChange} />

            <a
              href={phoneLink}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-sm transition-all animate-emergency"
              aria-label={`Appeler ${SITE_CONFIG.phoneDisplay}`}
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>{SITE_CONFIG.phoneDisplay}</span>
            </a>

            <a
              href="#devis"
              className="inline-flex items-center gap-1 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
            >
              <span>{t.getQuote}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Mobile Right Bar: Language Icon Button and Menu Toggle */}
          <div className="flex items-center gap-2 sm:hidden">
            <LanguageSelector currentLang={currentLang} onLanguageChange={onLanguageChange} compact />
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors"
              aria-label="Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="sm:hidden border-t border-slate-100 bg-white px-4 pt-3 pb-5 space-y-3">
          {/* Mobile Language Bar inside drawer */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-semibold text-slate-500">
              {currentLang === "ar" ? "اللغة / Langue :" : "Langue / Language :"}
            </span>
            <div className="flex gap-1.5">
              {(["ar", "fr", "en"] as const).map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => {
                    onLanguageChange(l);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                    currentLang === l
                      ? "bg-blue-600 text-white"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {l === "ar" ? "🇲🇦 ع" : l === "fr" ? "🇫🇷 FR" : "🇬🇧 EN"}
                </button>
              ))}
            </div>
          </div>

          <nav className="flex flex-col gap-1 text-sm font-semibold text-slate-700">
            <a
              href="#services"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-50"
            >
              {t.services}
            </a>
            <a
              href="#fes"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-50"
            >
              {t.coverage}
            </a>
            <a
              href="#faq"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-50"
            >
              {t.faq}
            </a>
            <a
              href="#devis"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-50 text-blue-600"
            >
              {t.getQuote}
            </a>
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-50"
            >
              {t.contact}
            </a>
          </nav>

          <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
            <a
              href={phoneLink}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-orange-500 text-white font-bold text-sm shadow-sm"
            >
              <PhoneCall className="w-4 h-4" />
              <span>{SITE_CONFIG.phoneDisplay} (Urgence 24/7)</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
