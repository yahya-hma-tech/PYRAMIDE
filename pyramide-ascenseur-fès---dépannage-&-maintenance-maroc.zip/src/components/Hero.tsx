import React from "react";
import { PhoneCall, ShieldCheck, Clock, CheckCircle2, MessageSquare, ArrowRight } from "lucide-react";
import { SITE_CONFIG, phoneLink, getWhatsappLink } from "../config";
import { InteractiveElevatorDemo } from "./InteractiveElevatorDemo";
import type { Translations } from "../translations";

interface HeroProps {
  t: Translations["hero"];
  demoT: Translations["demo"];
}

export const Hero: React.FC<HeroProps> = ({ t, demoT }) => {
  return (
    <section id="accueil" className="relative bg-gradient-to-b from-slate-50 via-white to-slate-50 pt-8 pb-16 lg:pt-14 lg:pb-24 overflow-hidden">
      {/* Background Subtle Mesh (Zero external requests) */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-100 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-10 w-80 h-80 bg-orange-50 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Punchy, High-Performance Copy */}
          <div className="lg:col-span-7 space-y-6">
            {/* Top Local Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200/60 text-blue-800 text-xs font-bold tracking-wide">
              <span className="w-2 h-2 rounded-full bg-blue-600" />
              <span>{t.badge}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.15]">
              {t.titleStart}{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-800">
                {t.titleHighlight}
              </span>{" "}
              {t.titleEnd}
            </h1>

            {/* Concise Subtitle (Short & clear, no bloated wall of text) */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              {t.subtitle}
            </p>

            {/* Primary Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {/* Emergency Call */}
              <a
                href={phoneLink}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all hover:-translate-y-0.5 active:translate-y-0"
              >
                <PhoneCall className="w-4 h-4 animate-bounce" />
                <span>{t.ctaCall} ({SITE_CONFIG.phoneDisplay})</span>
              </a>

              {/* Get Quote */}
              <a
                href="#devis"
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm transition-all hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>{t.ctaQuote}</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              {/* WhatsApp */}
              <a
                href={getWhatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold text-sm transition-colors"
              >
                <MessageSquare className="w-4 h-4 text-emerald-600" />
                <span>{t.ctaWhatsapp}</span>
              </a>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-200/80 max-w-lg">
              <div className="bg-white/80 p-3 rounded-xl border border-slate-200/60 shadow-2xs">
                <div className="flex items-center gap-1.5 text-blue-600 mb-0.5">
                  <Clock className="w-4 h-4" />
                  <span className="font-extrabold text-sm sm:text-base text-slate-900">{t.quickStats.speed}</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">{t.quickStats.speedSub}</p>
              </div>

              <div className="bg-white/80 p-3 rounded-xl border border-slate-200/60 shadow-2xs">
                <div className="flex items-center gap-1.5 text-blue-600 mb-0.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span className="font-extrabold text-sm sm:text-base text-slate-900">{t.quickStats.experience}</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">{t.quickStats.experienceSub}</p>
              </div>

              <div className="bg-white/80 p-3 rounded-xl border border-slate-200/60 shadow-2xs">
                <div className="flex items-center gap-1.5 text-orange-500 mb-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="font-extrabold text-sm sm:text-base text-slate-900">{t.quickStats.coverage}</span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">{t.quickStats.coverageSub}</p>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Elevator Simulation Widget */}
          <div className="lg:col-span-5" id="simulation">
            <InteractiveElevatorDemo t={demoT} />
          </div>
        </div>
      </div>
    </section>
  );
};
