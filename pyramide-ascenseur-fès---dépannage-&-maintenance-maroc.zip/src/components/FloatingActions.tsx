import React, { useState, useEffect } from "react";
import { PhoneCall, MessageSquare, ArrowUp } from "lucide-react";
import { SITE_CONFIG, phoneLink, getWhatsappLink } from "../config";

export const FloatingActions: React.FC = () => {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setShowTop(window.scrollY > 400);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <aside aria-label="Boutons d'action rapide" className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-3 pointer-events-auto">
      {/* Scroll to Top */}
      {showTop && (
        <button
          type="button"
          onClick={scrollToTop}
          aria-label="Retour en haut"
          className="w-10 h-10 rounded-full bg-slate-800/80 hover:bg-slate-900 text-white shadow-md flex items-center justify-center transition-all hover:scale-105 backdrop-blur-xs"
        >
          <ArrowUp className="w-4 h-4" />
        </button>
      )}

      {/* WhatsApp Button */}
      <a
        href={getWhatsappLink()}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Discussion WhatsApp"
        className="flex items-center gap-2 pl-3.5 pr-4 py-2.5 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/30 transition-all hover:scale-105 font-bold text-xs"
      >
        <MessageSquare className="w-5 h-5 fill-current" />
        <span className="hidden sm:inline">WhatsApp</span>
      </a>

      {/* Emergency Call Button */}
      <a
        href={phoneLink}
        aria-label={`Appeler ${SITE_CONFIG.phoneDisplay}`}
        className="flex items-center gap-2 px-4 py-3 rounded-full bg-orange-500 hover:bg-orange-600 text-white shadow-xl shadow-orange-500/35 transition-all hover:scale-105 font-black text-xs animate-emergency"
      >
        <PhoneCall className="w-4 h-4" />
        <span>{SITE_CONFIG.phoneDisplay}</span>
      </a>
    </aside>
  );
};
