import React from "react";
import { PhoneCall, Mail, MapPin, Clock, MessageSquare } from "lucide-react";
import { SITE_CONFIG, phoneLink, emailLink, getWhatsappLink } from "../config";
import type { Translations } from "../translations";

interface ContactSectionProps {
  t: Translations["contact"];
}

export const ContactDirectSection: React.FC<ContactSectionProps> = ({ t }) => {
  return (
    <section id="contact" className="py-16 bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-orange-400 bg-orange-950/80 px-3 py-1 rounded-full border border-orange-800">
            {t.tag}
          </span>
          <h2 className="mt-3 text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {t.title}
          </h2>
          <p className="mt-2 text-slate-300 text-sm">
            {t.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Phone */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center mb-4">
                <PhoneCall className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                {t.phoneLabel}
              </h3>
              <a
                href={phoneLink}
                className="text-lg font-black text-white hover:text-orange-400 transition-colors block mt-1"
              >
                {SITE_CONFIG.phoneDisplay}
              </a>
            </div>
            <p className="text-[11px] text-slate-400 mt-4">
              Ligne directe ouverte 24h/24 & 7j/7
            </p>
          </div>

          {/* Email */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center mb-4">
                <Mail className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                {t.emailLabel}
              </h3>
              <a
                href={emailLink}
                className="text-xs sm:text-sm font-semibold text-slate-200 hover:text-white break-all transition-colors block mt-1"
              >
                {SITE_CONFIG.email}
              </a>
            </div>
            <p className="text-[11px] text-slate-400 mt-4">
              Réponse rapide sous 24h ouvrées
            </p>
          </div>

          {/* WhatsApp */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-4">
                <MessageSquare className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                WhatsApp Direct
              </h3>
              <a
                href={getWhatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="text-base font-bold text-emerald-400 hover:text-emerald-300 transition-colors block mt-1"
              >
                Chat Instantané
              </a>
            </div>
            <p className="text-[11px] text-slate-400 mt-4">
              Envoi de photos & localisation
            </p>
          </div>

          {/* Location */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-6 flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center mb-4">
                <MapPin className="w-5 h-5" />
              </div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                {t.addressLabel}
              </h3>
              <p className="text-xs font-medium text-slate-200 mt-1 leading-relaxed">
                {SITE_CONFIG.address}
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-4">
              <Clock className="w-3.5 h-3.5" />
              <span>{SITE_CONFIG.hours}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
