import React, { useState, useRef, useEffect } from "react";
import { Globe, Check, ChevronDown } from "lucide-react";
import type { Language } from "../translations";

interface LanguageSelectorProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  compact?: boolean;
}

const LANGUAGES: Array<{ code: Language; name: string; nativeName: string; flag: string }> = [
  { code: "ar", name: "Arabe", nativeName: "العربية", flag: "🇲🇦" },
  { code: "fr", name: "Français", nativeName: "Français", flag: "🇫🇷" },
  { code: "en", name: "Anglais", nativeName: "English", flag: "🇬🇧" },
];

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  currentLang,
  onLanguageChange,
  compact = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const activeLang = LANGUAGES.find((l) => l.code === currentLang) || LANGUAGES[1];

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  const handleSelect = (code: Language) => {
    onLanguageChange(code);
    setIsOpen(false);
  };

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      {/* Trigger Button with Globe Icon */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        aria-haspopup="true"
        aria-expanded={isOpen}
        aria-label="Choisir la langue / اختر اللغة"
        className={`flex items-center gap-1.5 rounded-xl border transition-all ${
          compact
            ? "p-2 bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700"
            : "px-3 py-1.5 bg-slate-50 hover:bg-slate-100 border-slate-200/90 text-slate-700 shadow-2xs"
        }`}
      >
        <Globe className="w-4 h-4 text-blue-600 shrink-0" />
        <span className="text-base leading-none">{activeLang.flag}</span>
        <span className="text-xs font-bold uppercase tracking-wider hidden sm:inline">
          {activeLang.code}
        </span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${
            isOpen ? "rotate-180 text-blue-600" : ""
          }`}
        />
      </button>

      {/* Language Dropdown Menu */}
      {isOpen && (
        <div
          role="menu"
          aria-orientation="vertical"
          className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-48 rounded-2xl bg-white p-1.5 shadow-xl border border-slate-200/90 z-50 animate-in fade-in zoom-in-95 duration-150"
        >
          <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 mb-1">
            {currentLang === "ar" ? "اختر اللغة" : "Choisir la langue / Language"}
          </div>

          {LANGUAGES.map((lang) => {
            const isSelected = currentLang === lang.code;
            return (
              <button
                key={lang.code}
                type="button"
                role="menuitem"
                onClick={() => handleSelect(lang.code)}
                className={`w-full flex items-center justify-between gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
                  isSelected
                    ? "bg-blue-50 text-blue-700"
                    : "text-slate-700 hover:bg-slate-50 hover:text-slate-900"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-lg leading-none">{lang.flag}</span>
                  <div className="text-left rtl:text-right">
                    <span className="block font-bold">{lang.nativeName}</span>
                    <span className="block text-[10px] text-slate-400 font-normal">
                      {lang.name}
                    </span>
                  </div>
                </div>

                {isSelected && (
                  <Check className="w-4 h-4 text-blue-600 shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
