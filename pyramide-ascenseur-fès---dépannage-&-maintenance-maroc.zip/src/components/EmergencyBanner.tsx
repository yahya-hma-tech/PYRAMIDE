import React from "react";
import { Siren, PhoneCall } from "lucide-react";
import { SITE_CONFIG, phoneLink } from "../config";
import type { Translations } from "../translations";

interface EmergencyBannerProps {
  t: Translations["emergencyBar"];
}

export const EmergencyBanner: React.FC<EmergencyBannerProps> = ({ t }) => {
  return (
    <div className="bg-slate-950 text-white text-xs border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="relative flex h-2 w-2 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500" />
          </span>
          <span className="bg-orange-500 text-white px-1.5 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider shrink-0">
            {t.badge}
          </span>
          <span className="text-slate-300 font-medium truncate text-[11px] sm:text-xs">
            <Siren className="w-3.5 h-3.5 inline mx-1 text-orange-400 shrink-0" />
            {t.text}
          </span>
        </div>

        <a
          href={phoneLink}
          className="inline-flex items-center gap-1.5 font-bold text-orange-400 hover:text-orange-300 transition-colors shrink-0 text-xs pl-2"
        >
          <PhoneCall className="w-3.5 h-3.5" />
          <span className="font-mono">{SITE_CONFIG.phoneDisplay}</span>
        </a>
      </div>
    </div>
  );
};
