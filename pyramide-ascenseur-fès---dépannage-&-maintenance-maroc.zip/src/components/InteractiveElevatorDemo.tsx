import React, { useState, useEffect } from "react";
import { ArrowUp, ArrowDown } from "lucide-react";
import type { Translations } from "../translations";

interface ElevatorDemoProps {
  t: Translations["demo"];
}

const TOTAL_FLOORS = 5;

export const InteractiveElevatorDemo: React.FC<ElevatorDemoProps> = ({ t }) => {
  const [currentFloor, setCurrentFloor] = useState<number>(3);
  const [doorsOpen, setDoorsOpen] = useState<boolean>(false);
  const [isMoving, setIsMoving] = useState<boolean>(false);
  const [direction, setDirection] = useState<"up" | "down" | "idle">("idle");

  const goToFloor = (floor: number) => {
    if (floor === currentFloor || isMoving) return;
    setDoorsOpen(false);
    setIsMoving(true);
    setDirection(floor > currentFloor ? "up" : "down");

    // Move to floor after closing doors
    setTimeout(() => {
      setCurrentFloor(floor);
      setTimeout(() => {
        setIsMoving(false);
        setDirection("idle");
        setDoorsOpen(true);
        // auto-close after 3s
        setTimeout(() => setDoorsOpen(false), 3000);
      }, 700);
    }, 400);
  };

  useEffect(() => {
    // Initial welcome opening
    const timer = setTimeout(() => {
      setDoorsOpen(true);
      const closeTimer = setTimeout(() => setDoorsOpen(false), 2500);
      return () => clearTimeout(closeTimer);
    }, 600);
    return () => clearTimeout(timer);
  }, []);

  // Shaft calculations
  // Shaft height 280px, 5 floors: floor height = 48px
  const floorHeight = 44;
  const cabinY = (TOTAL_FLOORS - currentFloor) * floorHeight;

  return (
    <div className="bg-gradient-to-br from-slate-900 to-blue-950 rounded-2xl p-5 text-white shadow-xl border border-slate-800">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div>
          <h4 className="text-sm font-semibold text-slate-200">{t.title}</h4>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs text-slate-400">{t.status}</span>
          </div>
        </div>

        {/* Digital Floor Indicator */}
        <div className="bg-black/60 px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-2.5">
          <div className="flex items-center text-orange-400 font-mono font-bold text-lg">
            {direction === "up" && <ArrowUp className="w-4 h-4 text-emerald-400 animate-bounce" />}
            {direction === "down" && <ArrowDown className="w-4 h-4 text-orange-400 animate-bounce" />}
            {direction === "idle" && <span className="w-3" />}
            <span>{currentFloor === 0 ? "RDC" : `Niv ${currentFloor}`}</span>
          </div>
          <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-blue-900/60 text-blue-300">
            {doorsOpen ? t.doorsOpen : t.doorsClosed}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_130px] gap-4 items-center">
        {/* Elevator Shaft SVG Simulation */}
        <div className="relative bg-slate-950/70 rounded-xl p-3 border border-slate-800 flex items-center justify-center">
          <svg
            viewBox="0 0 220 250"
            className="w-full max-w-[200px] h-[230px]"
            role="img"
            aria-label="Simulation d'ascenseur"
          >
            {/* Shaft Guides */}
            <rect x="25" y="10" width="170" height="230" rx="8" fill="#030712" stroke="#1e293b" strokeWidth="2" />
            <line x1="45" y1="10" x2="45" y2="240" stroke="#334155" strokeWidth="2" strokeDasharray="4 4" />
            <line x1="175" y1="10" x2="175" y2="240" stroke="#334155" strokeWidth="2" strokeDasharray="4 4" />

            {/* Cable */}
            <line x1="110" y1="10" x2="110" y2={cabinY + 20} stroke="#64748b" strokeWidth="3" />

            {/* Floor indicators on the side */}
            {[5, 4, 3, 2, 1, 0].map((fl) => {
              const y = (TOTAL_FLOORS - fl) * floorHeight + 28;
              const isCurrent = currentFloor === fl;
              return (
                <g key={fl}>
                  <text
                    x="35"
                    y={y}
                    fontSize="9"
                    fontWeight="bold"
                    fill={isCurrent ? "#38bdf8" : "#475569"}
                    textAnchor="middle"
                  >
                    {fl === 0 ? "0" : fl}
                  </text>
                  <circle
                    cx="45"
                    cy={y - 3}
                    r={isCurrent ? 3 : 1.5}
                    fill={isCurrent ? "#38bdf8" : "#334155"}
                  />
                </g>
              );
            })}

            {/* Elevator Cabin */}
            <g
              style={{
                transform: `translateY(${cabinY}px)`,
                transition: "transform 0.7s cubic-bezier(0.25, 1, 0.5, 1)",
              }}
            >
              {/* Outer Cabin Shell */}
              <rect
                x="60"
                y="14"
                width="100"
                height="44"
                rx="6"
                fill="#1e293b"
                stroke="#38bdf8"
                strokeWidth={isMoving ? "2" : "1.5"}
              />

              {/* Cabin Interior Lighting */}
              <rect x="64" y="18" width="92" height="36" rx="3" fill="#0f172a" />
              <rect x="70" y="20" width="80" height="2" fill="#fef08a" opacity="0.8" />

              {/* Doors (Left & Right) */}
              {/* Left Door */}
              <rect
                x="64"
                y="18"
                width="46"
                height="36"
                fill="#334155"
                stroke="#475569"
                strokeWidth="1"
                style={{
                  transform: doorsOpen ? "translateX(-32px)" : "translateX(0)",
                  transition: "transform 0.4s ease-in-out",
                }}
              />
              {/* Right Door */}
              <rect
                x="110"
                y="18"
                width="46"
                height="36"
                fill="#334155"
                stroke="#475569"
                strokeWidth="1"
                style={{
                  transform: doorsOpen ? "translateX(32px)" : "translateX(0)",
                  transition: "transform 0.4s ease-in-out",
                }}
              />

              {/* Inside passenger silhouette visible when doors open */}
              <circle cx="110" cy="30" r="4" fill="#64748b" opacity={doorsOpen ? 1 : 0} />
              <path d="M104 44 C104 37 116 37 116 44 Z" fill="#64748b" opacity={doorsOpen ? 1 : 0} />
            </g>
          </svg>
        </div>

        {/* Floor Control Panel */}
        <div className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 flex flex-col justify-between">
          <p className="text-[11px] font-semibold text-slate-400 mb-2">{t.selectFloor}</p>
          <div className="grid grid-cols-2 gap-1.5">
            {[5, 4, 3, 2, 1, 0].map((fl) => {
              const active = currentFloor === fl;
              return (
                <button
                  key={fl}
                  type="button"
                  disabled={isMoving}
                  onClick={() => goToFloor(fl)}
                  className={`h-9 rounded-lg font-bold text-xs flex items-center justify-center transition-all ${
                    active
                      ? "bg-blue-600 text-white ring-2 ring-blue-400 shadow-md shadow-blue-500/30"
                      : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
                  } ${isMoving ? "opacity-60 cursor-not-allowed" : "cursor-pointer"}`}
                >
                  {fl === 0 ? "RDC" : `Etg ${fl}`}
                </button>
              );
            })}
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-800 text-[10px] text-slate-400 text-center">
            {isMoving ? (
              <span className="text-orange-400 animate-pulse font-medium">Déplacement en cours...</span>
            ) : doorsOpen ? (
              <span className="text-emerald-400 font-medium">Arrivé · Portes ouvertes</span>
            ) : (
              <span>Cabine prête</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
